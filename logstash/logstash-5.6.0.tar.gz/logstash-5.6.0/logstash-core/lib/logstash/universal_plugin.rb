# encoding: utf-8
module LogStash
  class UniversalPlugin
    def initialize
    end

    def register_hooks(hookManager)
    end

    def additionals_settings(settings)
    end
  end
end
