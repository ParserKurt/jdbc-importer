# encoding: utf-8
BUILD_INFO = {"build_date"=>"2017-09-07T03:43:10Z", "build_sha"=>"f17060d31ab11615b8909e7bb1fe4fde930d9a6d", "build_snapshot"=>false}