CREATE VIEW vw_account_campaign AS
  SELECT
    `c`.`id`            AS `campaign_id`,
    `c`.`name`          AS `campaign_name`,
    `a`.`id`            AS `account_id`,
    `t`.`name`          AS `timezone_name`,
    `ab`.`count_sms`    AS `balance_count_sms`,
    `ab`.`monetary`     AS `balance_monetary`,
    `ab`.`credit_limit` AS `balance_limit`,
    `bt`.`name`         AS `billing_type_name`,
    `g`.`id`            AS `gear_id`,
    `g`.`tps`           AS `gear_tps`
  FROM (((((`hawkeye`.`campaign` `c` LEFT JOIN `hawkeye`.`account` `a` ON ((`a`.`id` = `c`.`account_id`))) LEFT JOIN
    `hawkeye`.`timezone` `t` ON ((`t`.`id` = `a`.`timezone_id`))) LEFT JOIN `hawkeye`.`account_balance` `ab`
      ON ((`ab`.`account_id` = `a`.`id`))) LEFT JOIN `hawkeye`.`billing_type` `bt`
      ON ((`a`.`billing_type_id` = `bt`.`id`))) LEFT JOIN `hawkeye`.`turbo_gear` `g` ON ((`c`.`gear_id` = `g`.`id`)));
