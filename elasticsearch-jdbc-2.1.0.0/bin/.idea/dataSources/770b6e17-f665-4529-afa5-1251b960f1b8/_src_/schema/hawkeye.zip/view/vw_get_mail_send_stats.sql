CREATE VIEW vw_get_mail_send_stats AS
  SELECT
    `c`.`id`    AS `campaign_id`,
    count(0)    AS `count`,
    `ss`.`id`   AS `send_status_id`,
    `ss`.`code` AS `code`
  FROM (((`hawkeye`.`campaign` `c` LEFT JOIN `hawkeye`.`campaign_mail_bulk_q` `cqueue`
      ON ((`cqueue`.`campaign_id` = `c`.`id`))) LEFT JOIN `hawkeye`.`campaign_mail_bulk_send_q` `csqueue`
      ON ((`csqueue`.`campaign_mail_bulk_q_id` = `cqueue`.`id`))) LEFT JOIN `hawkeye`.`send_status` `ss`
      ON ((`ss`.`id` = `csqueue`.`send_status_id`)))
  GROUP BY `ss`.`id`, `c`.`id`;
