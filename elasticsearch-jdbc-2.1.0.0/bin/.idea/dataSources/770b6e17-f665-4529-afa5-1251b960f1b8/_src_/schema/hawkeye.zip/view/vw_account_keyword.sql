CREATE VIEW vw_account_keyword AS
  SELECT
    `kp`.`account_id`           AS `account_id`,
    `kp`.`primary_keyword_id`   AS `primary_id`,
    `k1`.`name`                 AS `primary_name`,
    `k1`.`keyword_handler_id`   AS `primary_handler_id`,
    `kh1`.`name`                AS `primary_handler_name`,
    `kh1`.`method`              AS `primary_handler_method`,
    `kh1`.`code`                AS `primary_handler_code`,
    `kp`.`secondary_keyword_id` AS `secondary_id`,
    `k2`.`name`                 AS `secondary_name`,
    `kp`.`keyword_handler_id`   AS `secondary_handler_id`,
    `kp`.`success_message`      AS `success_message`,
    `kp`.`error_message`        AS `error_message`,
    `kp`.`input_checker`        AS `input_checker`,
    `kp`.`save_to_group`        AS `save_to_group`,
    `kp`.`group_name`           AS `group_name`,
    `kh2`.`name`                AS `secondary_handler_name`,
    `kh2`.`code`                AS `secondary_handler_code`
  FROM ((((`hawkeye`.`keyword_pair` `kp` LEFT JOIN `hawkeye`.`keyword` `k1`
      ON ((`k1`.`id` = `kp`.`primary_keyword_id`))) LEFT JOIN `hawkeye`.`keyword` `k2`
      ON ((`k2`.`id` = `kp`.`secondary_keyword_id`))) LEFT JOIN `hawkeye`.`keyword_handler` `kh1`
      ON ((`kh1`.`id` = `k1`.`keyword_handler_id`))) LEFT JOIN `hawkeye`.`keyword_handler` `kh2`
      ON ((`kh2`.`id` = `kp`.`keyword_handler_id`)));
