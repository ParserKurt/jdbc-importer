CREATE VIEW vw_account_operator_pricing AS
  SELECT
    `o`.`id`           AS `operator_id`,
    `aop`.`price`      AS `operator_price_custom`,
    `aop`.`account_id` AS `account_id`
  FROM (`hawkeye`.`operator` `o` LEFT JOIN `hawkeye`.`account_operator_pricing` `aop`
      ON ((`aop`.`operator_id` = `o`.`id`)));
