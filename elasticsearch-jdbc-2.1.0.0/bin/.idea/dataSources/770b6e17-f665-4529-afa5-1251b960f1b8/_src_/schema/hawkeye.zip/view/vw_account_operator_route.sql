CREATE VIEW vw_account_operator_route AS
  SELECT
    1 AS `operator_id`,
    1 AS `route_id_custom`,
    1 AS `account_id`;
