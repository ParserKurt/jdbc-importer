CREATE VIEW vw_account_keyword2 AS
  SELECT
    1 AS `account_id`,
    1 AS `primary_id`,
    1 AS `primary_name`,
    1 AS `primary_handler_id`,
    1 AS `primary_handler_name`,
    1 AS `primary_handler_method`,
    1 AS `primary_handler_code`,
    1 AS `secondary_id`,
    1 AS `secondary_name`,
    1 AS `secondary_handler_id`,
    1 AS `success_message`,
    1 AS `error_message`,
    1 AS `input_checker`,
    1 AS `save_to_group`,
    1 AS `group_name`,
    1 AS `secondary_handler_name`,
    1 AS `secondary_handler_code`;
