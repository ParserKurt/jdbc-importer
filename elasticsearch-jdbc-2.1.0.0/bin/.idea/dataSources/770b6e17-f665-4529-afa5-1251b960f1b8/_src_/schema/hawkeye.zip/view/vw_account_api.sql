CREATE VIEW vw_account_api AS
  SELECT
    `a`.`id`            AS `account_id`,
    `t`.`name`          AS `timezone_name`,
    `at`.`api_token`    AS `account_api_token`,
    `ab`.`count_sms`    AS `balance_count_sms`,
    `ab`.`monetary`     AS `balance_monetary`,
    `ab`.`credit_limit` AS `balance_limit`,
    `bt`.`name`         AS `billing_type_name`,
    `a`.`timezone_id`   AS `timezone_id`
  FROM ((((`hawkeye`.`account` `a` LEFT JOIN `hawkeye`.`timezone` `t` ON ((`t`.`id` = `a`.`timezone_id`))) LEFT JOIN
    `hawkeye`.`account_technical_setting` `at` ON ((`a`.`id` = `at`.`account_id`))) LEFT JOIN
    `hawkeye`.`account_balance` `ab` ON ((`ab`.`account_id` = `a`.`id`))) LEFT JOIN `hawkeye`.`billing_type` `bt`
      ON ((`a`.`billing_type_id` = `bt`.`id`)));
